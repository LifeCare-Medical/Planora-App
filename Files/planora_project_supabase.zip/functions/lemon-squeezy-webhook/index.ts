// Supabase Edge Function: Lemon Squeezy Webhook Handler
// Handles payment success events and updates user's is_pro status

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

// HMAC-SHA256 signature verification
async function verifySignature(
  payload: string,
  signature: string,
  secret: string
): Promise<boolean> {
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign("HMAC", key, encoder.encode(payload));
  const computedHex = Array.from(new Uint8Array(sig))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
  return computedHex === signature;
}

serve(async (req: Request) => {
  // Only accept POST requests
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    // Get the raw body for signature verification
    const rawBody = await req.text();

    // Verify webhook signature
    const signature = req.headers.get("x-signature");
    const webhookSecret = Deno.env.get("LEMON_SQUEEZY_WEBHOOK_SECRET");

    if (!webhookSecret) {
      console.error("LEMON_SQUEEZY_WEBHOOK_SECRET not configured");
      return new Response(
        JSON.stringify({ error: "Webhook secret not configured" }),
        { status: 500, headers: { "Content-Type": "application/json" } }
      );
    }

    if (!signature) {
      console.error("No signature provided in request");
      return new Response(
        JSON.stringify({ error: "No signature provided" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );
    }

    const isValid = await verifySignature(rawBody, signature, webhookSecret);
    if (!isValid) {
      console.error("Invalid webhook signature");
      return new Response(
        JSON.stringify({ error: "Invalid signature" }),
        { status: 401, headers: { "Content-Type": "application/json" } }
      );
    }

    // Parse the webhook payload
    const payload = JSON.parse(rawBody);
    const eventName = payload.meta?.event_name;
    const customerEmail = payload.data?.attributes?.user_email;

    console.log(`Received event: ${eventName} for email: ${customerEmail}`);

    // Handle relevant events
    const activationEvents = [
      "order_created",
      "subscription_created",
      "subscription_payment_success",
    ];

    const deactivationEvents = [
      "subscription_expired",
      "subscription_cancelled",
    ];

    if (activationEvents.includes(eventName) && customerEmail) {
      // Initialize Supabase admin client
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseServiceKey);

      // Find the user by email in auth.users
      const { data: users, error: listError } =
        await supabase.auth.admin.listUsers();

      if (listError) {
        console.error("Error listing users:", listError.message);
        return new Response(
          JSON.stringify({ error: "Failed to query users" }),
          { status: 500, headers: { "Content-Type": "application/json" } }
        );
      }

      const user = users.users.find((u: any) => u.email === customerEmail);

      if (!user) {
        console.error(`No user found with email: ${customerEmail}`);
        return new Response(
          JSON.stringify({
            error: "User not found",
            email: customerEmail,
          }),
          { status: 404, headers: { "Content-Type": "application/json" } }
        );
      }

      // Update is_pro to true in profiles table
      const { error: updateError } = await supabase
        .from("profiles")
        .update({ is_pro: true })
        .eq("id", user.id);

      if (updateError) {
        // If profile doesn't exist, try upserting
        const { error: upsertError } = await supabase
          .from("profiles")
          .upsert({
            id: user.id,
            is_pro: true,
          });

        if (upsertError) {
          console.error("Error updating profile:", upsertError.message);
          return new Response(
            JSON.stringify({ error: "Failed to update profile" }),
            { status: 500, headers: { "Content-Type": "application/json" } }
          );
        }
      }

      console.log(`✅ User ${customerEmail} (${user.id}) upgraded to Pro`);
      return new Response(
        JSON.stringify({
          success: true,
          message: `User ${customerEmail} upgraded to Pro`,
          event: eventName,
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }

    // Handle subscription cancellation/expiry
    if (deactivationEvents.includes(eventName) && customerEmail) {
      const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
      const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const supabase = createClient(supabaseUrl, supabaseServiceKey);

      const { data: users } = await supabase.auth.admin.listUsers();
      const user = users.users.find((u: any) => u.email === customerEmail);

      if (user) {
        await supabase
          .from("profiles")
          .update({ is_pro: false })
          .eq("id", user.id);

        console.log(`⚠️ User ${customerEmail} Pro status deactivated`);
      }

      return new Response(
        JSON.stringify({
          success: true,
          message: `Handled ${eventName} for ${customerEmail}`,
        }),
        { status: 200, headers: { "Content-Type": "application/json" } }
      );
    }

    // Acknowledge other events
    console.log(`Event ${eventName} received but no action taken`);
    return new Response(
      JSON.stringify({
        success: true,
        message: `Event ${eventName} acknowledged`,
      }),
      { status: 200, headers: { "Content-Type": "application/json" } }
    );
  } catch (err) {
    console.error("Webhook processing error:", err);
    return new Response(
      JSON.stringify({ error: "Internal server error" }),
      { status: 500, headers: { "Content-Type": "application/json" } }
    );
  }
});
